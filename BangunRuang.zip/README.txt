# BangunRuang
PROJEK FINAL Praktikum Pemrograman Berorientasi Objek, Kelompok Inovasi.

PROJECT TITLE: Bangun Ruang
PURPOSE OF PROJECT: Projek Final
VERSION or DATE: 3/01/21 - 7/01/21
HOW TO START THIS PROJECT: Execute main
AUTHORS: Mizwar Zulfachri, Toyly Ashyyev, Asdar Rasyid, Azzahra Geubrina, Jessy Hanifiah, Maghfirah Nursiam, Anis Mahyatul Fauza
